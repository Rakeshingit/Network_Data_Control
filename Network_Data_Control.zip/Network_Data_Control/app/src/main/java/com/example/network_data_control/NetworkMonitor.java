package com.example.network_data_control;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.os.Build;
import android.telephony.PhoneStateListener;
import android.telephony.ServiceState;
import android.telephony.TelephonyCallback;
import android.telephony.TelephonyCallbackCompat;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.widget.Toast;


public class NetworkMonitor {
}
